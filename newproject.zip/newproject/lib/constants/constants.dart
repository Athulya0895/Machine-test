import 'package:flutter/material.dart';

import 'package:flutter/material.dart';

const ktextColor = Color(0xff535353);
const ktextlightColor = Color(0xffacacac);
const kdefaultPadding = 20;
