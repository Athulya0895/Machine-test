class Messages {
  static const String serverError = "Server Error";
  static const String unknownError = "Unknown Error";
}
