import 'package:newproject/base/base_view_model.dart';

class SettingsVM extends BaseViewModel {
  @override
  void onInit() {
    // TODO: implement onInit
  }
}
