class ApiConfig {
  static String baseUrl = "https://fakestoreapi.com";
  static String login = "";
  static String getProduct = "/products";
}
