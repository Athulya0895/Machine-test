package com.example.newproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
